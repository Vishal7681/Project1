package com.customercreation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerCreationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerCreationApplication.class, args);
	}

}
