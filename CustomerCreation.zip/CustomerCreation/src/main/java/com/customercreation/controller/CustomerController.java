package com.customercreation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.customercreation.module.Customer;
import com.customercreation.service.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerService s;
	
	@PostMapping("/addDetails")
	public ResponseEntity<Customer> addDeatails(@RequestBody Customer c){
		return new ResponseEntity<Customer>(s.saveCustomer(c),HttpStatus.CREATED);
	}
	
	
}
