package com.customercreation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.customercreation.module.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Integer> {
	
	
	
}
                                                      