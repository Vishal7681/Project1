package com.customercreation.service;

import com.customercreation.module.Customer;

public interface CustomerService {
	
	public Customer saveCustomer(Customer c);
	
	
	
}
