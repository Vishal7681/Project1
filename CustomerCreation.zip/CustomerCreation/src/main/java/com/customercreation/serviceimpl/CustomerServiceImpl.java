package com.customercreation.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.customercreation.module.Customer;
import com.customercreation.repository.CustomerRepo;
import com.customercreation.service.CustomerService;

@Service
public class CustomerServiceImpl implements	CustomerService{
	
	@Autowired
	CustomerRepo repo;
	
	@Override
	public Customer saveCustomer(Customer c) {
		
		if(c.getCustomerOccupation()=="Developer" || c.getCustomerOccupation()=="chef"	|| c.getCustomerOccupation()=="plumber"
				|| c.getCustomerOccupation()=="carpenter"	|| c.getCustomerOccupation()=="other") {
			repo.save(c);
		}
		return repo.save(c);
			
		
		
	}
	
}
